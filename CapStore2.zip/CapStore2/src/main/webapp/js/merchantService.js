
app.controller('MerchantAddProductController', function($scope) {
    
    $scope.message = 'This is add product screen for merchant';
     
});
 
