package com.flp.fms.domain;

public class Category {
	
	//private fields
		private int categoryId;
		private String categoryName;
		
		//no argument constructor
		public Category(){
			
		}
		

		//constructor with arguments
		public Category(int categoryId, String categoryName) {
			super();
			this.categoryId = categoryId;
			this.categoryName = categoryName;
		}
		

		//Getters and Setters
		public int getCategoryId() {
			return categoryId;
		}

		public void setCategoryId(int categoryId) {
			this.categoryId = categoryId;
		}

		public String getCategoryName() {
			return categoryName;
		}

		public void setCategoryName(String categoryName) {
			this.categoryName = categoryName;
		}

		
		//toString method implementation
		@Override
		public String toString() {
			return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + "]";
		}
		
	
}
