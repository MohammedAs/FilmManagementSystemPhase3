package com.flp.fms.dao;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorDao {
	
	public List<Actor> getActors();
	
}
