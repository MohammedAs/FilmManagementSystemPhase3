/**
 * 
 */

function isValidTitle()
{
	var title=addfilm.filmtitle.value;
	
	if(title.match(/*/^[A-Za-z]+$/*/  /^[A-Za-z0-9_ ]*$/
			))
		{
		document.getElementById("titleErr").innerHTML="";
		return true;
		}
	else{
		document.getElementById("titleErr").innerHTML="*Title should only contain alphabet"; 
		title.focus();  
		return false; 
	}
	
}


function isValidLength()  
{  
	var len=addfilm.filmduration.value;
   
   if(len.match(/^[0-9]+$/))  
   {  
	   document.getElementById("lengthErr").innerHTML="";
  
   return true;  
   }  
   else  
   {  
	   document.getElementById("lengthErr").innerHTML="*Length should only contain numbers";   
	   len.focus();   
   return false;  
   }  
}   

function isValidCost()  
{  
   
   if(addfilm.filmreplacementcost.value.match(/^[0-9]+$/))  
   {  
	   document.getElementById("costErr").innerHTML="";
  
   return true;  
   }  
   else  
   {  
	   document.getElementById("costErr").innerHTML="*Cost should only contain numbers";   
	   filmreplacementcost.focus();   
   return false;  
   }  
}
   
   function isValidRentalDate()  
   {  
      
	   var release=addfilm.releasedate.value;
	   var rental=addfilm.rentaldate.value;
      if(rental>release)  
      {  
   	   document.getElementById("dateErr").innerHTML="";
     
      return true;  
      }  
      else  
      {  
   	   document.getElementById("dateErr").innerHTML="*Rental date should be after release date";   
   	  release.focus();   
      return false;  
      }  
}   
