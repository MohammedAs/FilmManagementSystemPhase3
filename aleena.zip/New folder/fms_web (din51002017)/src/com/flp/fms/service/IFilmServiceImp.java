package com.flp.fms.service;

import java.util.ArrayList;


import com.flp.fms.dao.FilmDAO;
import com.flp.fms.dao.FilmDAOImp;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


//Service implementation layer for Film
public class IFilmServiceImp implements IFilmService {
	FilmDAO filmdao=new FilmDAOImp();
	
	//Overriden method to add films
	@Override
	public void addFilm(Film film) {
		
		filmdao.addFilm(film);
	}
	
	//Overriden method to list languages
	@Override
	public ArrayList<Language> displayLanguages() {
		// TODO Auto-generated method stub
		return filmdao.displayLanguages();
	}
	
	//Overriden method to list categories
	@Override
	public ArrayList<Category> displayCategory() {
		// TODO Auto-generated method stub
		return filmdao.displayCategory();
	}
	
	//Overriden method to show all films
	@Override
	public ArrayList<Film> getAllfilms() {
		// TODO Auto-generated method stub
		return filmdao.getAllfilms();
	}
	
	//Overriden method to delete film
	@Override
	public Boolean deleteFilm(int filmid) {
		// TODO Auto-generated method stub
		return filmdao.deleteFilm(filmid);
	}
	
	//Overriden method to search film
	@Override
	public ArrayList<Film> searchFilm(Film film) {
		// TODO Auto-generated method stub
		return filmdao.searchFilm(film);
	}
	
	//Overriden method to update film
	@Override
	public Boolean updateFilm(Film film) {
		// TODO Auto-generated method stub
		return filmdao.updateFilm(film);
	}
	

}
