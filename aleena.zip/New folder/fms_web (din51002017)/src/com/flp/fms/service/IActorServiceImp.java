package com.flp.fms.service;

import java.util.ArrayList;


import com.flp.fms.dao.IActorDAO;
import com.flp.fms.dao.IActorDAOImp;
import com.flp.fms.domain.Actor;

//Actor Service Implementation layer
public class IActorServiceImp implements IActorService {

	IActorDAO actordao=new IActorDAOImp();
	
	//Overriden method to list actors
	@Override
	public ArrayList<Actor> displayActors() {
		return actordao.displayActors();
	}

}


