package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;


//Actor Service Layer 
public interface IActorService {
	
	//Method to list actors
	ArrayList<Actor> displayActors();

}
