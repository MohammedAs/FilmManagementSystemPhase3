package com.flp.fms.service;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

//Film Service Layer
public interface IFilmService {
	
	//Method to list languages
	ArrayList<Language> displayLanguages();
	void addFilm(Film film);
	
	//Method to list categories
	ArrayList<Category> displayCategory();
	
	//Method to show all films
	ArrayList<Film> getAllfilms();
	
	//Method to delete films
	Boolean deleteFilm(int filmid);
	
	//Method to search films
	ArrayList<Film> searchFilm(Film film);
	
	//Method to update films
	Boolean updateFilm(Film film);
	
}
