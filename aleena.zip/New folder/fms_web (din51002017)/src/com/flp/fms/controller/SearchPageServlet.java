package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IActorServiceImp;
import com.flp.fms.service.IFilmService;
import com.flp.fms.service.IFilmServiceImp;

/**
 * Servlet implementation class SearchPageServlet
 */
//User Interaction page to search films
    public class SearchPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService =new IFilmServiceImp();
		IActorService actorService=new IActorServiceImp();
		
		//list all languages using filmService object
		ArrayList<Language> languages=filmService.displayLanguages();
		
		//list all Actors using actorService object
		ArrayList<Actor>actors=actorService.displayActors();
		
		//Function is called to list all categories using filmService object 
		ArrayList<Category>category=filmService.displayCategory();
		PrintWriter out=response.getWriter();
		
		//HTML code to display the search form
		out.println("<!DOCTYPE html>"+
		"<html>"+
		"<head> "
		+ "<link rel='stylesheet' type='text/css' href='css/myStyles.css'>"
		+"<meta charset='ISO-8859-1'>"
		+ "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
		+"     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
	    +"  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
	   + "<script type='text/javascript' src=''></script>"
				
		
				
				
		
		 
		      +"<!-- Javascript -->"
		  +"    <script>"
		  +"       $(function() {"
		     +"       $( '#datepicker1' ).datepicker({maxDate:'0', dateFormat:'dd-MM-yy'});"
		        +"    $( '#datepicker1' ).datepicker('show');"
		         +"});"
		         + "</script>"
		+"<title>Search Film</title>"+
		"</head>"
		+"<body >"
		+"<form name='searchForm' action='SearchServlet'>"
		+"<h3 id='add'>Search.. </h3>" 
		
			+"<table id='addtable'>"
				+"<tr>"
				+ "<td>"
				+" By FilmId:<input type='text' name='byId'/> "
				+"</td>"
				+ "</tr>"
				
				
				
				
				
				
				
				+"<tr>"
				+ "<td>"
				
				
				
				
				
				
				
		
				+"By Rating:<input type='text' name='byRating'/> "
				+"</td>"
				+ "</tr>"
				+"	<tr>"
				+"	<td>Release Date:<input type='text' id='datepicker1' name='releasedate' size='20'>"
				+"	</td>"
				+"	</tr>"
		        +"<tr>"
				+ "	<td>"
				+"By Title:<input type='text' name='byTitle'/> "
		        +"</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>"
		+"By Language:<br><select id='act' name='byLanguage'>"
				+"<option value='0'>--Select--</option>");
		  for(Language lang:languages){
				out.println("<option value='"+ lang.getLanguage_Id()+"'>"
						+lang.getLanguage_Name()+ "</option>");	
		   }
		out.println("</select>");
		out.println("</td>"
		+"</tr>"
	
		+"<tr>"
		+"<td>"
		+"By Actor:<br><select id='act' name='byActor'>"
				+ "<option value='0'>--Select--</option>");
		for(Actor act: actors)
		{
			out.println("<option value='"+act.getActor_Id()+"'>"
					+act.getActor_First_Name()+" "+act.getActor_last_Name()
					+"</option>");
			
		}
		out.println("</select>");
		out.println("</td>"
		  +"</tr>"
				+ "<tr>"
				+ "<td>"
				+ "<input id='search' type='submit' value='Search' name='search'> <br>"
				+ "</td>"
				+ "</tr>"
				

		+"</table>"
		
	
	
	
		+"</form>"
		+"</body>"
		+"</html>");
	}

    }

