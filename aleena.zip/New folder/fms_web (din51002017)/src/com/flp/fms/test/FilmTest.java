package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.FilmDAOImp;
import com.flp.fms.dao.IActorDAOImp;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.IFilmServiceImp;

public class FilmTest {
	
	FilmDAOImp  ifilmdao=new FilmDAOImp();
	IActorDAOImp iactordao=new IActorDAOImp();
	
	@Test
	public void TestWhetherAllLanguagesAreThere(){
		
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1,"English"));
		languages.add(new Language(2,"Malayalam"));
		languages.add(new Language(3,"Hindi"));
		languages.add(new Language(4,"Tamil"));
		languages.add(new Language(5,"Punjabi"));
		languages.add(new Language(6,"Telugu"));
		languages.add(new Language(7,"Marathi"));
		
		assertEquals(languages, ifilmdao.displayLanguages());
	}
	
	@Test
	public void TestWhetherAllCategoriesAreThere(){
		List<Category> category=new ArrayList<>();
		category.add(new Category(1,"Drama"));
		category.add(new Category(2,"Romance"));
		category.add(new Category(3,"Sci-fi"));
		category.add(new Category(4,"Horror"));
		category.add(new Category(5,"Comedy"));
		category.add(new Category(6,"Action"));
		
		assertEquals(category,ifilmdao.displayCategory());
	}
	
	@Test
	public void TestWhetherAllActorsAreThere(){
		
		List<Actor> actor=new ArrayList<>();
		actor.add(new Actor(1,"Shahrukh","Khan"));
		actor.add(new Actor(2,"Aamir","Khan"));
		actor.add(new Actor(3,"Salman","Khan"));
		actor.add(new Actor(4,"Saif Ali","Khan"));
		actor.add(new Actor(5,"Deepika ","Padukone"));
		actor.add(new Actor(6,"Kangana","Ranaut"));
		actor.add(new Actor(7,"Priyanka","Chopra"));
		actor.add(new Actor(8,"Alia","Bhatt"));
		actor.add(new Actor(9,"Sidharth","Malhotra"));
		actor.add(new Actor(10,"Varun","Dhawan"));
		actor.add(new Actor(11,"Leornado","DiCaprio"));
		actor.add(new Actor(12,"Kate","Winslet"));
		actor.add(new Actor(13,"Brad","Pitt"));
		actor.add(new Actor(14,"Angelina","Jolie"));
		actor.add(new Actor(15,"Dulquer","Salman"));
		actor.add(new Actor(16,"Fahad","Fazil"));
		actor.add(new Actor(17,"Nazriya","Nazim"));
		
		assertEquals(actor,iactordao.displayActors());
	}
	@Test
	public void  TestWhetherReturnTheNumberOfCategory() {
	
		

		assertEquals( 6,ifilmdao.displayCategory().size() );
		
	}
	
	@Test
	public void  TestWhetherReturnTheNumberOfLanguages() {
	
		

		assertEquals( 7,ifilmdao.displayLanguages().size() );
		
	}
	
	//Test Case for film Present or not	
		@Test
		public void isFilmNotPresent()
		{
			 List<Film> films=ifilmdao.getAllfilms();
			 Film film1=new Film();
			 for(Film film:films)
				 film1=film;
	        assertNotEquals(film1, ifilmdao.searchFilm(film1));
		}
		
		//TEST CASE FOR CATEGORY to check null	
		@Test
		public void isCategoryObjectIsNull() {
			
			Category category=null;
			assertNotEquals(category, ifilmdao.displayCategory());
			
		} 
		

		
}
