package com.flp.fms.dao;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

//DAO Layer for Film  
public interface FilmDAO {

	//Method to list languages
	ArrayList<Language> displayLanguages();
	
	//Method to add film
	void addFilm(Film film);
	
	//Method to list categories
	ArrayList<Category> displayCategory();
	
	//Method to show all films
	ArrayList<Film> getAllfilms();
	
	//Method to delete film
	Boolean deleteFilm(int filmid);
	
	//Method to search film
	ArrayList<Film> searchFilm(Film film);
	
	//Method to update film
	Boolean updateFilm(Film film);
	
}