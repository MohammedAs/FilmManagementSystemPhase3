package com.flp.fms.dao;

import java.util.ArrayList;

import com.flp.fms.domain.Actor;

//Dao layer for actors
public interface IActorDAO {
	
	//Method declaration to list actors
	ArrayList<Actor> displayActors();

}
