package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import java.sql.Date;

//DAO Implementation Layer for Film 
public class FilmDAOImp implements FilmDAO {
	
//Connect to database	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("connected...");
		
		return connection;
	}
    //add films into database
	@Override
	public void addFilm(Film film) {
	 Connection con=getConnection();
	 String sql="insert into film(Description,Title,releaseyear,Original_language_id,Rental_Duration,LENGTH,repalcement_cost,Rating,Special_Features,category_id)"
				+ "	 values(?,?,?,?,?,?,?,?,?,?)";
	 
	 try {
		 	PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1,film.getDescription() );
			pst.setString(2,film.getTitle() );	
			pst.setDate(3,new java.sql.Date(film.getRelease_Year().getTime()));
			pst.setInt(4,film.getOriginal_Language().getLanguage_Id());
			pst.setDate(5,new java.sql.Date(film.getRental_Duration().getTime()));
			pst.setInt(6,film.getLength());
			pst.setDouble(7,film.getReplacement_Cost());
			pst.setInt(8,film.getRatings());
			pst.setString(9,film.getSpecial_Features());
			Category cat=film.getCategory();
			pst.setInt(10,cat.getCategory_Id());
			int count=pst.executeUpdate();
			//if insertion to film table is success execute
			if(count>0){
				
			//insertion to third party tables
				int filmId=0;
				
				sql="select film_id from film order by film_id desc limit 1";
						
				PreparedStatement stmt = con.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()){
						
					filmId = rs.getInt(1);
				}
				
				
				sql="insert into film_actor(film_id,Actor_id) values(?,?)";
				pst = con.prepareStatement(sql);
				
				//getting all the actors in the film
				Set<Actor> actors = film.getActors();			
				for(Actor act: actors){
					pst.setInt(1, filmId );
					pst.setInt(2, act.getActor_Id());
					
					count=pst.executeUpdate();
				}
				
								
				sql="insert into film_language(film_id,language_id) values(?,?)";
				pst = con.prepareStatement(sql);
				
				//getting all the other languages
				List<Language> languages = film.getLanguages();				
				for(Language lang: languages){
					pst.setInt(1, filmId );
					pst.setInt(2, lang.getLanguage_Id());
					
					count=pst.executeUpdate();
				}
			
		}} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	//Overriden method to list all languages
	@Override
	public ArrayList<Language> displayLanguages() {
	Connection con=getConnection();
	ArrayList<Language> languages=new ArrayList<Language>();
	 String sql="select * from language";
		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				languages.add(new Language(rs.getInt(1),rs.getString(2)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
	}


	//Overriden method to list all categories
	@Override
	public ArrayList<Category> displayCategory() {
		Connection con=getConnection();	
		ArrayList<Category> categories=new ArrayList<Category>();
		 String sql="select * from category";
			try {
				PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					categories.add(new Category(rs.getInt(1),rs.getString(2)));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return categories;
	}

	//Overriden method to show all films in database
	@Override
	public ArrayList<Film> getAllfilms() {
		Connection con=getConnection();	
		ArrayList<Film> films=new ArrayList<Film>();
		 String sql="select * from film";
		 
			try {
				PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					Film film=new Film();
					film.setFilm_Id(rs.getInt(1));
					film.setDescription(rs.getString(2));
					film.setTitle(rs.getString(3));
					film.setRelease_Year(rs.getDate(4));
					
					String subsql;
					subsql="select language_name from language where language_id="+rs.getInt(5);
					PreparedStatement pst1=con.prepareStatement(subsql);
					ResultSet rs3=pst1.executeQuery();
					Language lang=new Language();
					if(rs3.next())
					{
						lang.setLanguage_Id(rs.getInt(5));
						lang.setLanguage_Name(rs3.getString(1));
					}
					film.setOriginal_Language(lang);
					film.setRental_Duration(rs.getDate(6));
					film.setLength(rs.getInt(7));
					film.setReplacement_Cost(rs.getInt(8));
					film.setRatings(rs.getInt(9));
					film.setSpecial_Features(rs.getString(10));
					
					subsql="select name from category where category_id="+rs.getInt(11);
					PreparedStatement pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
					if(rs3.next())
					{
						Category cat=new Category();
						cat.setCategory_Id(rs.getInt(11));
						cat.setCategory_Name(rs3.getString(1));
						film.setCategory(cat);
					}
					
					subsql="select language_id from film_language where film_id="+rs.getInt(1);
					System.out.println(rs.getInt(1));
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Language> languages=new ArrayList<>();
					while(rs3.next())
					{
												
						String subsql1="select language_name from language where language_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Language langs=new Language();
							langs.setLanguage_Id(rs3.getInt(1));
							langs.setLanguage_Name(rs1.getString(1));
							languages.add(langs);
							
						}
					}
					film.setLanguages(languages);
					subsql="select Actor_id from film_actor where film_id="+rs.getInt(1);
				
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    Set<Actor> actors=new HashSet<>();
					while(rs3.next())
					{
						String subsql1="select first_name,last_name from actor where actor_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Actor actr=new Actor();
							actr.setActor_First_Name(rs1.getString(1));
							actr.setActor_last_Name(rs1.getString(2));
							actr.setActor_Id(rs3.getInt(1));
							actors.add(actr);
							
						}
					}
					film.setActors(actors);
					film.setLanguages(languages);
					System.out.println(film);
					films.add(film);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return films;
	}
	
	//Overriden method to delete film from database
	@Override
	public Boolean deleteFilm(int filmid) {
		Connection con=getConnection();
		boolean flag=false;
		String sql= "DELETE film,film_actor,film_language FROM film LEFT JOIN film_actor ON film.film_id = film_actor.film_id LEFT JOIN film_language ON film_language.film_id = film.film_id WHERE film.film_id  =?" ;

		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, filmid);
			int count=pst.executeUpdate();
			
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}


	//Overriden method to search films stored in database
	@Override
	public ArrayList<Film> searchFilm(Film film) 
	{
		Connection con=getConnection();
		int count=0;
		String sql="select * from film where";
		ArrayList<Film> films=new ArrayList<Film>();
		System.out.println(film);
		if(film!=null)
		{
			if(film.getFilm_Id()>0)
			{
				
				sql+=" film_id="+film.getFilm_Id();
				
				count=1;
			}
			
			if(film.getTitle()!=null)
			{
				if(count==1)
				{
					sql+=" and Title='"+film.getTitle()+"'";
				}
				else
				{
					sql+=" Title='"+film.getTitle()+"'";
				}
				count=2;
			}
		

			if(film.getRatings()>0)
			{
				if(count==1||count==2)
				{
					sql+=" and rating="+film.getRatings();
				}
				else
				{
					sql+=" rating="+film.getRatings();
				}
				count=3;
			}
			if(film.getActors()!=null)
			{
				Actor actor=new Actor();
				Set<Actor> act=film.getActors();
				for(Actor a:act)
					actor=a;
				if(count==1||count==2||count==3)
				{
					sql+=" and film_id In(Select film_id from film_actor where actor_id="+actor.getActor_Id()+")";
					
				}else
				{
				sql+=" film_id In(Select film_id from film_actor where actor_id="+actor.getActor_Id()+")";
				}
				count=4;
			}
			if(film.getLanguages()!=null)
			{
				Language lang=new Language();
				List<Language> langs=film.getLanguages();
			
				for(Language l:langs)
					lang=l;
				if(count==1||count==2||count==3||count==4)
				{
					sql+=" and( film_id In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or film_id In( Select film_id from film where Original_language_id="+lang.getLanguage_Id()+"))";
					
				}else
				{
				sql+=" ( film_id In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or film_id In (Select film_id from film where Original_language_id="+lang.getLanguage_Id()+"))";
				
				}
				count=5;
			}
		
			 
			if(film.getRelease_Year()!=null)
			{
				if(count==1||count==2||count==3||count==4||count==5)
				{
					sql+=" and releaseyear='"+new java.sql.Date(film.getRelease_Year().getTime())+"'";
				}
				else
				{
					sql+=" releaseyear='"+new java.sql.Date(film.getRelease_Year().getTime())+"'";
				}
				count=6;
			}
			System.out.println(sql);
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
			
				while(rs.next())
				{
					Film film1=new Film();
					film1.setFilm_Id(rs.getInt(1));
					film1.setDescription(rs.getString(2));
					film1.setTitle(rs.getString(3));
					film1.setRelease_Year(rs.getDate(4));
					
					String subsql;
					subsql="select language_name from language where language_id="+rs.getInt(5);
					PreparedStatement pst1=con.prepareStatement(subsql);
					ResultSet rs3=pst1.executeQuery();
					Language lang=new Language();
					if(rs3.next())
					{
						lang.setLanguage_Id(rs.getInt(5));
						lang.setLanguage_Name(rs3.getString(1));
					}
					film1.setOriginal_Language(lang);
					film1.setRental_Duration(rs.getDate(6));
					film1.setLength(rs.getInt(7));
					film1.setReplacement_Cost(rs.getInt(8));
					film1.setRatings(rs.getInt(9));
					film1.setSpecial_Features(rs.getString(10));
					
					subsql="select name from category where category_id="+rs.getInt(11);
					PreparedStatement pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
					if(rs3.next())
					{
						Category cat=new Category();
						cat.setCategory_Id(rs.getInt(11));
						cat.setCategory_Name(rs3.getString(1));
						film1.setCategory(cat);
					}
					
					subsql="select language_id from film_language where film_id="+rs.getInt(1);
					System.out.println(rs.getInt(1));
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Language> languages=new ArrayList<>();
					while(rs3.next())
					{
												
						String subsql1="select language_name from language where language_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Language langs=new Language();
							langs.setLanguage_Id(rs3.getInt(1));
							langs.setLanguage_Name(rs1.getString(1));
							languages.add(langs);
							
						}
					}
					film1.setLanguages(languages);
					subsql="select Actor_id from film_actor where film_id="+rs.getInt(1);
				
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    Set<Actor> actors=new HashSet<>();
					while(rs3.next())
					{
						String subsql1="select first_name,last_name from actor where actor_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Actor actr=new Actor();
							actr.setActor_First_Name(rs1.getString(1));
							actr.setActor_last_Name(rs1.getString(2));
							actr.setActor_Id(rs3.getInt(1));
							actors.add(actr);
							
						}
					}
					film1.setActors(actors);
					film1.setLanguages(languages);
					System.out.println(film1);
					films.add(film1);
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		
		return films;
	}



	//Overriden method to update films stored in database
	@Override
	public Boolean updateFilm(Film film ) {

		Connection con=getConnection();
		 String sql="Update film Set Description=?,Title=?,releaseyear=?,Original_language_id=?,Rental_Duration=?,LENGTH=?,repalcement_cost=?,Rating=?,Special_Features=?,category_id=? where film_id="+film.getFilm_Id();
		 
		 try {
			 	PreparedStatement pst = con.prepareStatement(sql);
				pst.setString(1,film.getDescription() );
				pst.setString(2,film.getTitle() );	
				pst.setDate(3,new java.sql.Date(film.getRelease_Year().getTime()));
				pst.setInt(4,film.getOriginal_Language().getLanguage_Id());
				pst.setDate(5,new java.sql.Date(film.getRental_Duration().getTime()));
				pst.setInt(6,film.getLength());
				pst.setDouble(7,film.getReplacement_Cost());
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecial_Features());
				Category cat=film.getCategory();
				pst.setInt(10,cat.getCategory_Id());
				int count=pst.executeUpdate();
				//if insertion to film table is success execute
				if(count>0){
					
					//insertion to third party tables
					int filmId=film.getFilm_Id();
					
							
					sql="delete from film_actor where film_id="+filmId;
					PreparedStatement stmt = con.prepareStatement(sql);
					int count1= stmt.executeUpdate();
					
					sql="insert into film_actor(film_id,Actor_id) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the actors in the film
					Set<Actor> actors = film.getActors();			
					for(Actor act: actors){
						pst.setInt(1, filmId );
						pst.setInt(2, act.getActor_Id());
						
						count=pst.executeUpdate();
					}
					
					sql="delete from film_language where film_id="+filmId;
					 stmt = con.prepareStatement(sql);
					 count1= stmt.executeUpdate();
									
					sql="insert into film_language(film_id,language_id) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the other languages
					List<Language> languages = film.getLanguages();				
					for(Language lang: languages){
						pst.setInt(1, filmId );
						pst.setInt(2, lang.getLanguage_Id());
						
						count=pst.executeUpdate();
					}
				
			}} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 return null;
	}


}
