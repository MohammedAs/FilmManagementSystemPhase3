package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;

/**
 * Servlet implementation class DeleteActorServlet
 */
public class DeleteActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteActorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actorService=new ActorServiceImpl();
		List<Actor> actors=actorService.getActorList();
		
		 PrintWriter out=response.getWriter();
	        
	        out.println("<html>");
			out.println("<head>List All Actors Details</head>"
					+ "<body style='color:white'>"
					
					
					+ "<table border='1'>"
					+ "<tr>"
					+ "<th>Actor Id</th>"
					+ "<th>First Name</th>"
					+ "<th>Last Name</th>"
					+ "</tr>");
			
				for(Actor actor:actors){
					out.println("<tr>");
					out.println("<td>"+actor.getActor_Id()+"</td>");
					out.println("<td>"+actor.getFirstName()+"</td>");
					out.println("<td>"+actor.getLastName()+"</td>");
					
					
					out.println("<td><a href='DeleteActor?actor_id="+actor.getActor_Id()+"'><font color='grey'>Delete</font></a></td>");
					out.println("</tr>");
				}
					out.println("</table></body>");
		
					out.println("</html>");
			
			
	        
	   
	}
	}


