package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddActorServlet
 */
public class AddActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddActorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		
		out.println("<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"+
                     "<script type='text/javascript' src='scripts/validate.js'></script>"+
                 
                     "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"+
           		 "     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"+
           		    "  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"+ 
                    "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"+
                     "<script type='text/javascript' src='scripts/jquery-1.8.3.js'></script>"+
                     "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.min.js'></script>"+
                     "     <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"+
         		    "  <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
                  /*   "    <script>"
           		  +"       $(function() {"
           		     +"       $( '#datepicker1' ).datepicker({maxDate:'0', dateFormat:'dd-MM-yy'});"
           		        +"    $( '#datepicker1' ).datepicker('show');"
           		         +"});"
           		         +"$(function() {"
           		           +  "$( '#datepicker2' ).datepicker({dateFormat:'dd-MM-yy'});"
           		            +" $( '#datepicker2' ).datepicker('show');"
           		         +" });"
           		      +"</script>"*/
           		      );
                    
			
		out.println("<title>Actor Details</title>");
		out.println("</head>");

		out.println("<body id='AddActorServlet' style='color:white;'>");
		
		out.println("<form name='actor' method='get'  action='SaveActorServlet'>");

		out.println("<h2><center>Actor Registration Form</center></h1>");
		out.print("<table align='center'>");

//		onblur='return validateField1()'

		out.println("<tr>"
			+"<td>First Name:</td>"
			+"<td><input type='text' name='actorname' size='20' ></td>"
			+"<td><div id='actorErr' class='errMsg'></div></td>"
			+"</tr>"
			+"<tr>");
		
		out.println("<tr>"
				+"<td>Last Name:</td>"
				+"<td><input type='text' name='lastname' size='20' ></td>"
				+"<td><div id='lnameErr' class='errMsg'></div></td>"
				+"</tr>"
				+"<tr>");
		
		
		
		out.println("<tr>"
				+"<td></td>"
				+"<td><input type='submit' value='Save'>"
				+"<input type='reset' value='Clear'>"
				 +"</td>"
			+"</tr>");
			
	out.println("</table>");


		out.println("</form>");


		out.println("</body>");
		out.println("</html>");
			


	}
	}

	
