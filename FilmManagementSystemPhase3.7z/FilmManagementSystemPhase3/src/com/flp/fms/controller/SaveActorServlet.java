package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.IActorService;

/**
 * Servlet implementation class SaveActorServlet
 */
public class SaveActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveActorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	PrintWriter out=response.getWriter();
		
		Actor actor=new Actor();
		
		IActorService actorService=new ActorServiceImpl();
		
		actor.setFirstName(request.getParameter("actorname"));
		actor.setLastName(request.getParameter("lastname"));
		
		actorService.addActor(actor);
//		if(actorService.addActor(actor)==1){
		request.getRequestDispatcher("AddActorServlet").forward(request, response);
		
	}
		
		
		
		
		
	

}
