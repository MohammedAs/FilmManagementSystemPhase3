package com.flp.fms.service;

import java.util.List;


import com.flp.fms.dao.ActorDaoImplForList;

import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService{

	ActorDaoImplForList actorDao=new ActorDaoImplForList();

	

	
	//To List all Actor
	@Override
	public List<Actor> getActorList() {
		
		return actorDao.getActorList();
	}

	//To Add Actor
	@Override
	public int addActor(Actor actor) {
		
		return actorDao.addActor(actor);
	}

	@Override
	public boolean deleteActorDetails(int actorid) {
		
		return actorDao.deleteActorDetails(actorid);
	}

	@Override
	public List<Actor> searchActorDetails(Actor actor) {
		
		return actorDao.searchActorDetails(actor);
	}

	@Override
	public Actor getSearchActorByID(int actorid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateActorDetails(int actorid, Actor actor) {
		// TODO Auto-generated method stub
		return 0;
	}


	
	
	
}
