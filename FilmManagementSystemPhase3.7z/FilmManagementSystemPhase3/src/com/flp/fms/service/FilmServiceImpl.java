package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


public class FilmServiceImpl implements IFilmService{



	
	private IFilmDao filmDao=new FilmDaoImplForList();

	//To Get Original Language
	public List<Language> getLanguages() {
		
//		System.out.println(filmDao.getLanguages());

		return filmDao.getLanguages();
		
	}
	//To Get Category
	public List<Category> getCategory() {
		
		System.out.println(filmDao.getCategory());

		return filmDao.getCategory();
}
	//To Add Film
	@Override
	public void addFilm(Film film) {
		
		
		filmDao.addFilm(film);
		
	}
	
	
	//To List all Films
	@Override
	public ArrayList<Film> getAllFilms() {
		
	return filmDao.getAllFilms();
}


		


	//To Delete Film
	@Override
	public Boolean deleteFilm(int filmid) {
	
		return filmDao.deleteFilm(filmid);
	}
	
	//To Search  Film 
	@Override
	public List<Film> searchFilm(Film film) {
	// TODO Auto-generated method stub
		return filmDao.searchFilm(film);
	}

	//To Update Film
	@Override
	public Boolean updateFilm(Film film) {
	
	return filmDao.updateFilm(film);
}


	

}


	

