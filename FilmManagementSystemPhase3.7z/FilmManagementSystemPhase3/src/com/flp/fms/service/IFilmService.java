package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


public interface IFilmService {

	//To List all Language
public  List<Language> getLanguages();
	
//To List all Category
	public  List<Category> getCategory();
	
	//To Add All Films
	public void addFilm(Film film);
	
	//To List All Films
	public ArrayList<Film> getAllFilms();
	
	//To Update Films
	Boolean updateFilm(Film film);
	
	//To Delete Films
	Boolean deleteFilm(int filmid);
	
	//To Search Films
	public List<Film> searchFilm(Film film);
	


}
