package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class JUnitTest {

	FilmDaoImplForList filmdao=new FilmDaoImplForList();
	IActorDao actorService= new ActorDaoImplForList(); 
	
	@Test
	public void test() {
		
	}

	
	
	@Test
	public void ListOfLanguagesIsNotNull(){
		List<Language> langs=new ArrayList<>();
		langs.add(new Language(1,"Hindi"));
		langs.add(new Language(2,"English"));
		langs.add(new Language(3,"Telgu"));
		langs.add(new Language(4,"Marathi"));
		langs.add(new Language(5,"Malyallam"));
	
		assertEquals(filmdao.getLanguages(),langs);
	}
	
	
	@Test
	public void WhenListOfLanguagesIsNull(){
		assertEquals(null,null);
	}
	
	@Test
	public void ListOfActorsIsNotNull(){
		List<Actor> actors=new ArrayList<>();
		actors.add(new Actor(1,"Pears","Brosnen"));
		actors.add(new Actor(2,"Win","Diseal"));
	
		
		actors.add(new Actor(3,"Will","Smith"));
		actors.add(new Actor(4,"Jason","Stathom"));
		actors.add(new Actor(5,"Zander","Cage"));
		assertEquals(actorService.getActorList(),actors);
		
	}



	@Test
	public void isFilmNotPresentToDelete()
	{
		
		 assertFalse(filmdao.deleteFilm(23));
		
	}


	@Test
	public void filmObjectIsNullWhenSearchById()
	{
		 Film film=null;
        assertNotEquals(film, filmdao.searchFilm(film));
	}
	
	 

	@Test
	public void isFilmNotPresent()
	{
		 List<Film> films=filmdao.getAllFilms();
		 Film film1=new Film();
		 for(Film film:films)
			 film1=film;
        assertNotEquals(film1, filmdao.searchFilm(film1));
	}
	
	
}

