package com.flp.fms.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class SaveFilmTestCase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
