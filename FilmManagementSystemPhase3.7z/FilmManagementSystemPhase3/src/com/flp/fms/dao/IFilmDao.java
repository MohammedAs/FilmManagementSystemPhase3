package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;


public interface IFilmDao {

	//To List all Language
	public List<Language> getLanguages();
	
	//To List all Category
	public List<Category> getCategory();
	
	//To List All Films
	public ArrayList<Film> getAllFilms();
	
	//To Search Films
	public List<Film> searchFilm(Film film);
	
	//To Delete Films
	public Boolean deleteFilm(int filmid);
	
	//To Add All Films
	void addFilm(Film film);
	
	//To Update Films
	Boolean updateFilm(Film film);
	
	
	
}
