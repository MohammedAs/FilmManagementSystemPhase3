package com.flp.fms.dao;

import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorDao {
	
	
	//To add Actor
	public int addActor(Actor actor);

	//To Get All Actor
	List<Actor> getActorList();
	
	public boolean deleteActorDetails(int actorid);
	
	public List<Actor> searchActorDetails(Actor actor);
	public Actor getSearchActorByID(int actorid);
	
	public int updateActorDetails(int actorid,Actor actor);
}
