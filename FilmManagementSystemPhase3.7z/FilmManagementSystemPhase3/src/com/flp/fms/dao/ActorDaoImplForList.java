package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;


public class ActorDaoImplForList implements IActorDao {

	 

	

	
	//To Get All Actor
	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();

		
		//Code to get Actors from Database
		FilmDaoImplForList filmDao=new FilmDaoImplForList();
		Connection con=filmDao.getConnection();
		
		String sql="select * from actortable";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setFirstName(rs.getString(2));
				actor1.setLastName(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}


	@Override
	public int addActor(Actor actor) {
		
		FilmDaoImplForList filmDao=new FilmDaoImplForList();
		Connection con=filmDao.getConnection();
		String sql="insert into actortable(CustFN,CustLN)values(?,?)";
		int count=0;
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			
			pst.setString(1, actor.getFirstName());
			pst.setString(2,actor.getLastName());
			
		 count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}


	@Override
	public boolean deleteActorDetails(int actorid) {
		boolean flag=false;
		String sql="delete from actortable where ActorId=?";
		FilmDaoImplForList filmDao=new FilmDaoImplForList();
		
		Connection con=filmDao.getConnection();
		
		   	 try {
					PreparedStatement pst=con.prepareStatement(sql);
				
				pst.setInt(1,actorid);
				 
				 
				 int count=pst.executeUpdate();
				 

					if(count>0)
						flag=true;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		   	 
		   	try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return flag;
	}


	//search actor from the database
		@Override
		public List<Actor> searchActorDetails(Actor actor) {
			
			FilmDaoImplForList filmDao=new FilmDaoImplForList();
			Connection con=filmDao.getConnection();
			
			int count=0;
			String sql="select * from actortable where";
			List<Actor> actors=new ArrayList<Actor>();
			
			if(actor!=null)
			{
				if(actor.getActor_Id()>0)
				{
					
					sql+=" ActorId="+actor.getActor_Id();
					
					count=1;
				}
				
				if(actor.getFirstName()!=null)
				{
					if(count==1)
					{
						sql+=" and CustFN='"+actor.getFirstName()+"'";
					}
					else
					{
						sql+=" CustFN='"+actor.getFirstName()+"'";
					}
					count=2;
				}
			}
			
		
				
				try {
					PreparedStatement pst= con.prepareStatement(sql);
					ResultSet rs=pst.executeQuery();
					
					while(rs.next())
					{
						Actor actor1=new Actor();
						actor1.setActor_Id(rs.getInt(1));
						actor1.setFirstName(rs.getString(2));
						actor1.setFirstName(rs.getString(3));
						
						actors.add(actor1);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			return actors;
		}

		@Override
		public Actor getSearchActorByID(int actorid)  {

			FilmDaoImplForList filmDao=new FilmDaoImplForList();
			Connection con=filmDao.getConnection();
			
			Actor actor=new Actor();
			
			String sql="select * from actortable where ActorId=?";
			
			
			try {
				PreparedStatement pst= con.prepareStatement(sql);
				pst.setInt(1, actorid);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
				
						actor.setActor_Id(rs.getInt(1));
						actor.setFirstName(rs.getString(2));
						actor.setLastName(rs.getString(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return actor;
		}


	//update actor
		@Override
		public int updateActorDetails(int actorid, Actor actor) {
			
			FilmDaoImplForList filmDao=new FilmDaoImplForList();
	         Connection con=filmDao.getConnection();
			System.out.println("DAO="+actorid);
			int count=0;
			
			String sql="update actortable set CustFN=?,CustFN=? where ActorId="+actorid;
			
			
				
				try {
					PreparedStatement pst = con.prepareStatement(sql);
					
					pst.setString(1,actor.getFirstName());
					pst.setString(2, actor.getLastName());
					
					count=pst.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			return count;
		}
}

	

		
	