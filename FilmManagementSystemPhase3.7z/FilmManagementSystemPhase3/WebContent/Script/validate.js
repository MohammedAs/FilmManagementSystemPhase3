function validateForm()

{

 var flag=true;
	
	
	
	var title = addfilm.filmtitle.value;
	
	var length = addfilm.filmlength.value;
	
	var cost=addfilm.replacementcost.value;
	
	var rentalDate = addfilm.rentalduration.value;
	
	var releaseyear=addfilm.releasedate.value;
	
	var letters = /^[A-Za-z0-9_ ]*$/;
	
	var actor=addfilm.actorname.value;
	
	var date1 = new Date(rentalDate).getTime();
	var date2 = new Date(releaseyear).getTime();
	
	
	 
		
	if((title==" " || title==null) || !title.match(letters) )
	
	{
		
		document.getElementById("titleerr").innerHTML="* Please enter a title";
		
		flag=false;
	}
	
	else
	 {
		document.getElementById("titleerr").innerHTML="";
	 }
	
   if((length == ""||length == null) || length > 1000)
   
   {
		
		document.getElementById("lenghterr").innerHTML="*Please enter a value below 1000";
		
		flag = false;
	}
   
	else
	 {
		document.getElementById("lenghterr").innerHTML="";
	    
	 }
   
   
   if((cost==""||cost==null) || cost < 10000)
   {
		
		document.getElementById("replacementcosterr").innerHTML="*Enter Valid Replacement Cost";
		
		flag = false;
	}
		
	else
		
		{
		document.getElementById("replacementcosterr").innerHTML="";
		
		}
   
   if((rentalDate==""||rentalDate==null))
   {
		
		document.getElementById("rentaldurationerr").innerHTML="*Enter valid date";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("rentaldurationerr").innerHTML="";
		}
   
//   rentalDate>releaseyear
   if((releaseyear==""||releaseyear==null))
   {
		
		document.getElementById("relasedatrr").innerHTML="*Invalid release date";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("relasedatrr").innerHTML="";
		}
   
   
   
   
   
   
   
   
   
   if((actor==" " || actor==null))
		
	{
		
		document.getElementById("actorErr").innerHTML="* Please enter a title";
		
		flag=false;
	}
	
	else
	 {
		document.getElementById("actorErr").innerHTML="";
	 }
	
   
   return flag;
   
}




 
   