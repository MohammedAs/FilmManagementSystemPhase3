package com.flp.fms.domain;

public class Language {

		//Private Fields
		private int language_Id;
		private String languageName;

	//No Argument Constructor	
	public Language(){}

	//Argument Constructor	
	public Language(int language_Id,String languageName){
		super();
			this.language_Id=language_Id;
			this.languageName=languageName;
	}

	//Getters And Setters
	public int getLanguage_Id() {
		return language_Id;
	}

	public void setLanguage_Id(int language_Id) {
		this.language_Id = language_Id;
	}

	public String getLanguageName() {
		return languageName;
	}

	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}

	@Override
	public String toString() {
		return "Language [language_Id=" + language_Id + ", languageName=" + languageName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((languageName == null) ? 0 : languageName.hashCode());
		result = prime * result + language_Id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Language other = (Language) obj;
		if (languageName == null) {
			if (other.languageName != null)
				return false;
		} else if (!languageName.equals(other.languageName))
			return false;
		if (language_Id != other.language_Id)
			return false;
		return true;
	}

	
	
}
