package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class JUnitTest {

	IFilmDao  serviceFilm=new FilmDaoImplForList();
	IActorDao actorService= new ActorDaoImplForList(); 
	
	@Test
	public void test() {
		
	}

	
	
	@Test
	public void ListOfLanguagesIsNotNull(){
		List<Language> langs=new ArrayList<>();
		langs.add(new Language(1,"Hindi"));
		langs.add(new Language(2,"English"));
		langs.add(new Language(3,"Telgu"));
		langs.add(new Language(4,"Marathi"));
		langs.add(new Language(5,"Malyallam"));
	
		assertEquals(serviceFilm.getLanguages(),langs);
	}
	
	
	@Test
	public void WhenListOfLanguagesIsNull(){
		assertEquals(null,null);
	}
	
	@Test
	public void ListOfActorsIsNotNull(){
		List<Actor> actors=new ArrayList<>();
		actors.add(new Actor(1,"Pears","Brosnen"));
		actors.add(new Actor(2,"Win","Diseal"));
	
		
		actors.add(new Actor(3,"Will","Smith"));
		actors.add(new Actor(4,"Jason","Stathom"));
		actors.add(new Actor(5,"Zander","Cage"));
		assertEquals(actorService.getActorList() , actors);
		
	}

}
//	@Test
//	public void ListOfCategoryIsNotNull(){
//		List<Actor> actors=new ArrayList<>();
//		actors.add(new Actor(1,"Pears","Brosnen"));
//		actors.add(new Actor(2,"Win","Diseal"));
//	
//		
//		actors.add(new Actor(3,"Will","Smith"));
//		actors.add(new Actor(4,"Jason","Stathom"));
//		actors.add(new Actor(5,"Zander","Cage"));
//		assertEquals(actorService.getActorList(), actors);
//		
//	}
	



