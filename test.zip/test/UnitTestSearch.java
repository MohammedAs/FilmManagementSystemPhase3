package com.flp.fms.test;

import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.*;
public class UnitTestSearch {

	@Test
	public void test() {
	}
	
	FilmService  serviceFilm=new FilmServiceImpl();
	
	
	
	@Test
	public void WhenListOfActorsIsNotNull(){
		List<Actor> actors=new ArrayList<>();
		actors.add(new Actor(1,"Will","Smith"));
		actors.add(new Actor(2,"Hugh","Jackman"));
	
		
		actors.add(new Actor(3,"Tom","Hnaks"));
		actors.add(new Actor(4,"Nana","Patekar"));
		actors.add(new Actor(5,"Ben","Kinsley"));
		assertEquals(serviceFilm.getActors(), actors);
		
	}
	
	@Test
	public void WhenListOfLanguagesIsNotNull(){
		List<Language> langs=new ArrayList<>();
		langs.add(new Language(1,"English"));
		langs.add(new Language(2,"Hindi"));
		langs.add(new Language(3,"Marathi"));
		langs.add(new Language(4,"Tamil"));
		langs.add(new Language(5,"Malyalam"));
		langs.add(new Language(6,"Bengali"));
		langs.add(new Language(7,"Korean"));
		assertEquals(serviceFilm.getLanguages(),langs);
	}
	
	@Test
	public void WhenListOfLanguagesIsNull(){
		assertEquals(null,null);
	}
	
	@Test
	public void WhenAddFilmObjectIsNotNull() throws ParseException{
		Film film=new Film();
		film.setFilm_Id(1);
		film.setCategory(new Category(1,"Romance"));
		film.setLength(456);
		Set<Actor> actors=new HashSet<>();
		actors.add(new Actor(1,"Will","Smith"));
		actors.add(new Actor(2,"Hugh","Jackman"));
		film.setActors(actors);
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1,"English"));
		languages.add(new Language(2,"Hindi"));
		film.setLanguages(languages);
		Language orglang=new Language();
		orglang.setLanguage_Id(1);
		orglang.setLanguage_Name("English");
		film.setOriginalLanguage(orglang);
		film.setTitle("Inception");
		film.setDescription("Intriguing");
		String strDate1 = "2016-04-06";
		DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date = formatter1.parse(strDate1);
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		film.setReleaseYear(sqlDate);
		String strDate2 = "2016-04-13";
		DateFormat formatter2 = new SimpleDateFormat("yyyy-mm-dd");

		java.util.Date date2 = formatter2.parse(strDate2);
		java.sql.Date sqlDate2 = new java.sql.Date(date.getTime());
		film.setRentalDuration(sqlDate2);
	assertEquals(serviceFilm.saveFilm(film), true);
	}

		

	    


}
