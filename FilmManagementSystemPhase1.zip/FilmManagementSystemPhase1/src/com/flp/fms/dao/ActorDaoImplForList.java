package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao {

	@Override
	public List<Actor> getActors() {
		
		List<Actor> actors = new ArrayList<>();
		
		actors.add(new Actor(101, "Sharuk", "Khan"));
		actors.add(new Actor(102, "Mohan", "Lal"));
		actors.add(new Actor(103, "Dulqer", "Salman"));
		actors.add(new Actor(104, "Manju", "Warrier"));
		actors.add(new Actor(105, "Nazriya", "Nazim"));
		actors.add(new Actor(106, "Nivin", "Pauly"));
		
		return actors;
	}

}
