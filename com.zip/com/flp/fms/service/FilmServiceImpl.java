package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService{

	
	private IFilmDao filmDoa=new FilmDaoImplForList();

	public List<Language> getLanguages() {
		
		System.out.println(filmDoa.getLanguages());

		return filmDoa.getLanguages();
		
	}
public List<Category> getCategory() {
		
		System.out.println(filmDoa.getCategory());

		return filmDoa.getCategory();
}
	@Override
	public void addFilm(Film film) {
		
		
		filmDoa.addFilm(film);
		
	}
	
	

@Override
public ArrayList<Film> getAllFilms() {
	// TODO Auto-generated method stub
	return filmDoa.getAllFilms();
}


		


@Override
public Boolean deleteFilm(int filmid) {
	// TODO Auto-generated method stub
	return filmDoa.deleteFilm(filmid);
}
@Override
public List<Film> searchFilm(Film film) {
	// TODO Auto-generated method stub
	return filmDoa.searchFilm(film);
}

}


	

