package org.capgemini.dao;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.UserLogin;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class UserLoginDaoImpl implements UserLoginDao {

	@Override
	public boolean isValidUser(UserLogin login) {
		Connection con=getConnection();
		boolean flag=false;
		String query="select * from userlogin where username=? and password=?";
		PreparedStatement stmt=null;
		try {
			stmt = (PreparedStatement) con.prepareStatement(query);
			stmt.setString(1, login.getUsername());
			stmt.setString(2,login.getPassword());
			ResultSet rs=stmt.executeQuery();
			if(rs.next())
				flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public Connection getConnection()
	{
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/javaflp","root","Pass123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public boolean addCustomerDetails(Customer customer) {
		Connection con=getConnection();
		boolean flag=false;
		String query="insert into customer(firstName,lastName,address,gender,regDate,regFee,custType) values(?,?,?,?,?,?,?)";
		PreparedStatement stmt=null;
		try {
			stmt = (PreparedStatement) con.prepareStatement(query);
			stmt.setString(1, customer.getFirstName());
			stmt.setString(2,customer.getLastName());
			stmt.setString(3, customer.getAddress());
			stmt.setString(4, customer.getGender());
			stmt.setDate(5, new Date(customer.getRegDate().getTime()));
			stmt.setDouble(6, customer.getRegFee());
			stmt.setString(7,customer.getCustType());
			stmt.executeUpdate();
				flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public ArrayList<Customer> listAllCustomers() {
		ArrayList<Customer> customers=new ArrayList<>();
		Connection con=getConnection();
		
		String query="select * from customer";
		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Customer cust=new Customer();
				
				cust.setCustid(rs.getInt(1));
	        cust.setFirstName(rs.getString(2));
	        cust.setLastName(rs.getString(3));
	        cust.setAddress(rs.getString(4));
	        cust.setGender(rs.getString(5));
	        cust.setRegDate(rs.getDate(6).valueOf(rs.getDate(6).toString()));
	        cust.setRegFee(rs.getDouble(7));
	        cust.setCustType(rs.getString(8));
	        customers.add(cust);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customers;
	}

	@Override
	public Customer searchCustomer(int custId) {
		Customer cust=new Customer();
		Connection con=getConnection();
		String query="select * from customer where custid=?";
		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(query);
			pst.setInt(1, custId);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				 cust.setFirstName(rs.getString(2));
			        cust.setLastName(rs.getString(3));
			        cust.setAddress(rs.getString(4));
			        cust.setGender(rs.getString(5));
			        cust.setRegDate(rs.getDate(6).valueOf(rs.getDate(6).toString()));
			        cust.setRegFee(rs.getDouble(7));
			        cust.setCustType(rs.getString(8));
			}
			else
			{
				cust=null;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cust;
	}

}
