package org.capgemini.demo;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.UserLoginService;
import org.capgemini.service.UserLoginServiceImpl;

/**
 * Servlet implementation class CreateCustomerServlet
 */
public class CreateCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserLoginService userloginservice=new UserLoginServiceImpl();
		Customer customer=new Customer();
		customer.setFirstName(request.getParameter("fname"));
		customer.setLastName(request.getParameter("lname"));
		customer.setGender(request.getParameter("gender"));
		customer.setAddress(request.getParameter("address"));
		customer.setCustType(request.getParameter("type"));
		customer.setRegFee(Double.parseDouble(request.getParameter("fee")));
		customer.setRegDate(new Date(request.getParameter("regdate")));
		userloginservice.addCustomerDetails(customer);
		request.getRequestDispatcher("htmlpages/CreateCustomer.html").forward(request, response);
	}

}
