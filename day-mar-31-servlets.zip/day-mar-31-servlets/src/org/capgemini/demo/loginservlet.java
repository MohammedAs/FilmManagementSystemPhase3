package org.capgemini.demo;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.UserLogin;
import org.capgemini.service.UserLoginService;
import org.capgemini.service.UserLoginServiceImpl;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class loginservlet
 */
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserLogin login=new UserLogin();
		UserLoginService userloginservice=new UserLoginServiceImpl();
		String user=request.getParameter("uname");
		String pass=request.getParameter("pass");
		
		login.setUsername(user);
		login.setPassword(pass);
		
		
		
		if(userloginservice.isValidUser(login))
			response.sendRedirect("htmlpages/success.html");
		else
			response.sendRedirect("htmlpages/login.html");
		
	}

}
