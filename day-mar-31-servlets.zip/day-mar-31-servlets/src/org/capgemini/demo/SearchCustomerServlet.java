package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.UserLoginServiceImpl;

/**
 * Servlet implementation class SearchCustomerServlet
 */
public class SearchCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Customer cust=new UserLoginServiceImpl().searchCustomer(Integer.parseInt(request.getParameter("custID")));
		if(cust!=null)
		{
			out.println("<html>");
			out.println("<head></head>");
			out.println("<body><h2>List of All Customers<h2>"
					+"<table>"
					+"<tr>"
					+"<th>Customer First name</th>"
					+"<th>Customer Last name</th>"
					+"<th>Address</th>"
					+"<th>Gender</th>"
					+"<th>Registration date</th>"
					+"<th>Registration fees"
					+"<th>Customer Type</th>"
					+"</tr>");
			
				out.println("<tr>");
				out.println("<td>"+cust.getFirstName()+
						"</td>");
				out.println("<td>"+cust.getLastName()+"</td>");
				out.println("<td>"+cust.getAddress()+"</td>");
				out.println("<td>"+cust.getGender()+"</td>");
				out.println("<td>"+cust.getRegDate()+"</td>");
				out.println("<td>"+cust.getRegFee()+"</td>");
				out.println("<td>"+cust.getCustType()+"</td>");
				out.println("</tr>");
			
				out.println("</table></body></html>");	
		}
		else{
			out.println("<h2>Customer Not Found</h2>");
		}
	}

	

}
