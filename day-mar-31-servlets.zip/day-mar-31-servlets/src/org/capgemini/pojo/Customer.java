package org.capgemini.pojo;

import java.util.Date;

public class Customer {
private String firstName;
private String lastName;
private String gender;
private String address;
private Date regDate;
private double regFee;
private String custType;
private int custid;

public int getCustid() {
	return custid;
}

public void setCustid(int custid) {
	this.custid = custid;
}

public Customer(){}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public Date getRegDate() {
	return regDate;
}

public void setRegDate(Date regDate) {
	this.regDate = regDate;
}

public double getRegFee() {
	return regFee;
}

public void setRegFee(double regFee) {
	this.regFee = regFee;
}

public String getCustType() {
	return custType;
}

public void setCustType(String custType) {
	this.custType = custType;
}

@Override
public String toString() {
	return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", address=" + address
			+ ", regDate=" + regDate + ", regFee=" + regFee + ", custType=" + custType + "]";
}


}
