package org.capgemini.service;

import java.util.ArrayList;

import org.capgemini.dao.UserLoginDao;
import org.capgemini.dao.UserLoginDaoImpl;
import org.capgemini.pojo.Customer;
import org.capgemini.pojo.UserLogin;

public class UserLoginServiceImpl implements UserLoginService {

	@Override
	public boolean isValidUser(UserLogin login) {
		UserLoginDao userlogindao=new UserLoginDaoImpl();
		return userlogindao.isValidUser(login);
	}

	@Override
	public boolean addCustomerDetails(Customer customer) {
		UserLoginDao userlogindao=new UserLoginDaoImpl();
		return userlogindao.addCustomerDetails(customer);
	}

	@Override
	public ArrayList<Customer> listAllCustomers() {
		UserLoginDao userlogindao=new UserLoginDaoImpl();
		return userlogindao.listAllCustomers();
	}

	@Override
	public Customer searchCustomer(int custId) {
		UserLoginDao userlogindao=new UserLoginDaoImpl();
		return userlogindao.searchCustomer(custId);
	}

}
 