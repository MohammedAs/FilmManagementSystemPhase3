package org.capgemini.service;

import java.util.ArrayList;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.UserLogin;

public interface UserLoginService {
public boolean isValidUser(UserLogin login);
public boolean addCustomerDetails(Customer customer);
public ArrayList<Customer> listAllCustomers();
public Customer searchCustomer(int custId);

}
