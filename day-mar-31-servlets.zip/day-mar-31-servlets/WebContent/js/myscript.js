function isValidInput()
{
	var flag=true;
	var uname=form1.uname.value;
	var pass=form1.pass.value;
	if(uname==""||uname==null)
		{
		document.getElementById("errmsg").innerHTML="Please enter username";
		flag=false;
		}
	else
		document.getElementById("errmsg").innerHTML="";
	if(pass==""||pass==null)
		{
		document.getElementById("errmsg1").innerHTML="Please enter password";
		flag=false;
		}
	else
		document.getElementById("errmsg1").innerHTML="";
	return flag;
}